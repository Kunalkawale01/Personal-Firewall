#!/usr/bin/env python3
"""firewall_core.py
Core engine for Personal Firewall.
"""
import json, logging, shlex, subprocess
from ipaddress import ip_network, ip_address
try:
    from scapy.all import sniff, IP, TCP, UDP, ICMP
except Exception:
    sniff = None
    IP = TCP = UDP = ICMP = None

LOGFILE = "firewall.log"
logger = logging.getLogger("personal_firewall")
if not logger.handlers:
    fh = logging.FileHandler(LOGFILE)
    fmt = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s')
    fh.setFormatter(fmt)
    logger.setLevel(logging.INFO)
    logger.addHandler(fh)

class RuleEngine:
    def __init__(self, path="rules.json"):
        self.path = path
        self.load_rules()

    def load_rules(self):
        try:
            with open(self.path) as f:
                raw = json.load(f)
            self.rules = []
            for r in raw:
                rule = {
                    "id": r.get("id"),
                    "action": r.get("action","block").lower(),
                    "direction": r.get("direction","any").lower(),
                    "proto": (r.get("proto") or "ANY").upper(),
                    "src_ip": r.get("src_ip"),
                    "dst_ip": r.get("dst_ip"),
                    "src_port": r.get("src_port"),
                    "dst_port": r.get("dst_port"),
                    "comment": r.get("comment","")
                }
                self.rules.append(rule)
            logger.info(f"Loaded {len(self.rules)} rules from {self.path}")
        except Exception:
            logger.exception("Failed to load rules")
            self.rules = []

    def save_rules(self):
        try:
            with open(self.path, 'w') as f:
                json.dump(self.rules, f, indent=2)
            logger.info("Saved rules to disk")
        except Exception:
            logger.exception("Failed to save rules")

    def match_packet(self, pkt):
        if IP is None or not pkt.haslayer(IP):
            return None
        src = pkt[IP].src
        dst = pkt[IP].dst
        proto = "ANY"
        sport = dport = None
        if pkt.haslayer(TCP):
            proto = "TCP"
            sport = pkt[TCP].sport
            dport = pkt[TCP].dport
        elif pkt.haslayer(UDP):
            proto = "UDP"
            sport = pkt[UDP].sport
            dport = pkt[UDP].dport
        elif pkt.haslayer(ICMP):
            proto = "ICMP"
        for rule in self.rules:
            if rule['proto'] != 'ANY' and rule['proto'] != proto:
                continue
            if rule['src_ip']:
                try:
                    if '/' in str(rule['src_ip']):
                        if ip_address(src) not in ip_network(rule['src_ip']):
                            continue
                    else:
                        if src != rule['src_ip']:
                            continue
                except Exception:
                    continue
            if rule['dst_ip']:
                try:
                    if '/' in str(rule['dst_ip']):
                        if ip_address(dst) not in ip_network(rule['dst_ip']):
                            continue
                    else:
                        if dst != rule['dst_ip']:
                            continue
                except Exception:
                    continue
            if rule['src_port'] is not None:
                if sport is None or int(rule['src_port']) != int(sport):
                    continue
            if rule['dst_port'] is not None:
                if dport is None or int(rule['dst_port']) != int(dport):
                    continue
            return rule
        return None

class IptablesManager:
    def __init__(self):
        self.added = set()
    def _run(self, cmd):
        try:
            subprocess.run(shlex.split(cmd), check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return True
        except subprocess.CalledProcessError as e:
            logger.error(f"iptables command failed: {e}")
            return False
    def add_drop(self, rule):
        parts = ["iptables", "-I", "INPUT", "1"]
        if rule['proto'] != 'ANY':
            parts += ["-p", rule['proto'].lower()]
        if rule['src_ip']:
            parts += ["-s", str(rule['src_ip'])]
        if rule['dst_ip']:
            parts += ["-d", str(rule['dst_ip'])]
        if rule['src_port']:
            parts += ["--sport", str(rule['src_port'])]
        if rule['dst_port']:
            parts += ["--dport", str(rule['dst_port'])]
        parts += ["-j", "DROP"]
        cmd = " ".join(parts)
        uid = cmd
        if uid in self.added:
            return False
        ok = self._run(cmd)
        if ok:
            self.added.add(uid)
            logger.info(f"Added iptables DROP rule: {cmd}")
            return True
        return False

def describe(pkt):
    if IP is None or not pkt.haslayer(IP):
        return "Non-IP packet"
    proto = 'UNK'
    sport = dport = '-'
    if pkt.haslayer(TCP):
        proto = 'TCP'
        sport = pkt[TCP].sport
        dport = pkt[TCP].dport
    elif pkt.haslayer(UDP):
        proto = 'UDP'
        sport = pkt[UDP].sport
        dport = pkt[UDP].dport
    elif pkt.haslayer(ICMP):
        proto = 'ICMP'
    return f"{pkt[IP].src}:{sport} -> {pkt[IP].dst}:{dport} proto={proto}"

class PacketHandler:
    def __init__(self, engine, enforce=False, ipt_mgr=None):
        self.engine = engine
        self.enforce = enforce
        self.ipt = ipt_mgr
    def __call__(self, pkt):
        try:
            rule = self.engine.match_packet(pkt)
            if rule:
                desc = describe(pkt)
                if rule['action'] == 'block':
                    logger.warning(f"BLOCKED ({rule['id']}): {desc} -- {rule.get('comment','')}")
                    if self.enforce and self.ipt:
                        self.ipt.add_drop(rule)
                else:
                    logger.info(f"ALLOWED ({rule['id']}): {desc}")
        except Exception:
            logger.exception("Error handling packet")

def start_sniff(engine=None, iface=None, enforce=False):
    if sniff is None:
        logger.error('scapy not available - cannot sniff packets')
        return
    if engine is None:
        engine = RuleEngine()
    ipt = IptablesManager() if enforce else None
    handler = PacketHandler(engine, enforce=enforce, ipt_mgr=ipt)
    logger.info('Starting sniff (press Ctrl+C to stop)...')
    sniff(prn=handler, store=False, iface=iface)

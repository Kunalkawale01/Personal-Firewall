#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import threading, time, json, os
from firewall_core import RuleEngine, start_sniff

LOGFILE = 'firewall.log'
RULES_FILE = 'rules.json'

class FirewallThread(threading.Thread):
    def __init__(self, engine, iface=None, enforce=False):
        super().__init__(daemon=True)
        self.engine = engine
        self.iface = iface
        self.enforce = enforce
        self._stop = threading.Event()
    def run(self):
        try:
            start_sniff(engine=self.engine, iface=self.iface, enforce=self.enforce)
        except Exception as e:
            print('Sniffing stopped:', e)
    def stop(self):
        self._stop.set()

class App:
    def __init__(self, root):
        self.root = root
        root.title('Personal Firewall - GUI')
        self.engine = RuleEngine(RULES_FILE)
        self.thread = None

        top = ttk.Frame(root, padding=8)
        top.pack(fill='x')
        ttk.Button(top, text='Start', command=self.start).pack(side='left')
        ttk.Button(top, text='Stop', command=self.stop).pack(side='left')
        ttk.Button(top, text='Add Rule', command=self.add_rule).pack(side='left')
        ttk.Button(top, text='Remove Rule', command=self.remove_rule).pack(side='left')
        ttk.Button(top, text='Reload Rules', command=self.reload_rules).pack(side='left')

        self.rules_list = tk.Listbox(root, height=6)
        self.rules_list.pack(fill='x', padx=8, pady=6)
        self.load_rules_into_list()

        log_frame = ttk.LabelFrame(root, text='Live Log', padding=6)
        log_frame.pack(fill='both', expand=True, padx=8, pady=6)
        self.log_text = tk.Text(log_frame, state='disabled')
        self.log_text.pack(fill='both', expand=True)

        self._stop_tail = threading.Event()
        self.tail_thread = threading.Thread(target=self._tail_log, daemon=True)
        self.tail_thread.start()

    def start(self):
        if self.thread and self.thread.is_alive():
            messagebox.showinfo('Info', 'Firewall already running.')
            return
        self.thread = FirewallThread(self.engine, enforce=False)
        self.thread.start()
        messagebox.showinfo('Started', 'Firewall started (sniffing in background).')

    def stop(self):
        if not self.thread:
            messagebox.showinfo('Info', 'Firewall is not running.')
            return
        messagebox.showinfo('Stop', 'To stop sniffing please close the terminal running CLI or press Ctrl+C.')

    def add_rule(self):
        rid = simpledialog.askstring('Rule ID', 'Enter rule id:')
        if not rid: return
        action = simpledialog.askstring('Action', 'block or allow:')
        proto = simpledialog.askstring('Protocol', 'TCP/UDP/ICMP/ANY (default ANY):') or 'ANY'
        src = simpledialog.askstring('Src IP', 'Src IP or CIDR (or blank):')
        dst = simpledialog.askstring('Dst IP', 'Dst IP or CIDR (or blank):')
        sport = simpledialog.askstring('Src Port', 'Src port (or blank):')
        dport = simpledialog.askstring('Dst Port', 'Dst port (or blank):')
        rule = {
            'id': rid,
            'action': (action or 'block').lower(),
            'direction': 'any',
            'proto': proto.upper(),
            'src_ip': src or None,
            'dst_ip': dst or None,
            'src_port': int(sport) if sport else None,
            'dst_port': int(dport) if dport else None,
            'comment': ''
        }
        self.engine.rules.append(rule)
        self.engine.save_rules()
        self.load_rules_into_list()

    def remove_rule(self):
        sel = self.rules_list.curselection()
        if not sel:
            messagebox.showwarning('Select', 'Select a rule to remove.')
            return
        idx = sel[0]
        rid = self.engine.rules[idx]['id']
        confirm = messagebox.askyesno('Confirm', f'Remove rule {rid}?')
        if confirm:
            del self.engine.rules[idx]
            self.engine.save_rules()
            self.load_rules_into_list()

    def reload_rules(self):
        self.engine.load_rules()
        self.load_rules_into_list()
        messagebox.showinfo('Reloaded', 'Rules reloaded from rules.json')

    def load_rules_into_list(self):
        self.rules_list.delete(0, 'end')
        for r in self.engine.rules:
            self.rules_list.insert('end', f"{r['id']} | {r['action']} | {r['proto']} | {r.get('dst_ip') or '-'}:{r.get('dst_port') or '-'}")

    def _tail_log(self):
        while not self._stop_tail.is_set():
            if os.path.exists(LOGFILE):
                with open(LOGFILE, 'r') as f:
                    f.seek(0, os.SEEK_END)
                    while not self._stop_tail.is_set():
                        line = f.readline()
                        if not line:
                            time.sleep(0.5)
                            continue
                        self._append_log(line)
            else:
                time.sleep(1)

    def _append_log(self, line):
        def inner():
            self.log_text.config(state='normal')
            self.log_text.insert('end', line)
            self.log_text.see('end')
            self.log_text.config(state='disabled')
        try:
            self.root.after(0, inner)
        except Exception:
            pass

    def on_close(self):
        self._stop_tail.set()
        self.root.destroy()

if __name__ == '__main__':
    root = tk.Tk()
    app = App(root)
    root.protocol('WM_DELETE_WINDOW', app.on_close)
    root.mainloop()

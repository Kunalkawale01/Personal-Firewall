#!/usr/bin/env python3
import argparse, signal, sys, logging
from firewall_core import start_sniff, RuleEngine

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger('personal_firewall_cli')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--enforce', action='store_true', help='Enable iptables enforcement (Linux)')
    parser.add_argument('--iface', help='Network interface to sniff (optional)')
    args = parser.parse_args()

    engine = RuleEngine('rules.json')
    def _signal(sig, frame):
        logger.info('Stopping firewall...')
        sys.exit(0)
    signal.signal(signal.SIGINT, _signal)
    start_sniff(engine=engine, iface=args.iface, enforce=args.enforce)

if __name__ == '__main__':
    main()

#!/bin/bash
if [ "$1" == "flush" ]; then
  echo "[*] Flushing filter chains..."
  sudo iptables -F
  echo "[+] Done."
else
  echo "Usage: sudo ./iptables_helper.sh flush"
fi

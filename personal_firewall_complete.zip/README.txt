Personal Firewall - Complete Project
Files:
- firewall_core.py   : Core engine (rules, iptables helper, sniff wrapper)
- firewall.py        : CLI launcher (run sniffing)
- gui_firewall.py    : Tkinter GUI (start/stop, add/remove rules, live logs)
- rules.json         : Sample rule set (edit as needed)
- iptables_helper.sh : Helper script to flush iptables (use with caution)
- firewall.log       : (created when running) log of events

Requirements (Linux or WSL with privileges):
1) Python 3.8+
2) scapy: pip install scapy
3) (optional) python3-tk for GUI: sudo apt install python3-tk
4) Running sniffing/enforcement requires root privileges:
   sudo python3 firewall.py
   sudo python3 firewall.py --enforce

Notes:
- The project uses scapy for sniffing; scapy may require root on many systems.
- iptables enforcement modifies system firewall; use --enforce only on systems you control.
- GUI cannot cleanly stop scapy.sniff started from within the same process; for full control run CLI in a terminal.
- Edit rules.json to add/remove persistent rules; GUI edits the same file.
